/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

import clasesDAO.ConsolaDao;
import clasesDAO.CriticaDao;
import clasesDAO.JuegoDao;
import clasesDAO.MarcaDao;
import clasesDAO.UsuarioDao;
import clasesDAO.VentaDao;
import clasesPojo.Consola;
import clasesPojo.Critica;
import clasesPojo.Juego;
import clasesPojo.Marca;
import clasesPojo.Usuario;
import clasesPojo.Venta;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Clase principal que contiene el menú de la aplicación. Permite gestionar
 * usuarios, marcas, consolas, juegos, críticas, ventas y ver estadísticas.
 *
 * @author pedro
 */
public class AppOptimizada {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDao bd = new UsuarioDao();
        MarcaDao bd2 = new MarcaDao();
        ConsolaDao bd3 = new ConsolaDao();
        JuegoDao bd4 = new JuegoDao();
        CriticaDao bd5 = new CriticaDao();
        VentaDao bd6 = new VentaDao();
        ArrayList<Usuario> listaUsuarios = new ArrayList<>();
        ArrayList<Marca> listaMarcas = new ArrayList<>();
        ArrayList<Consola> listaConsolas = new ArrayList<>();
        ArrayList<Juego> listaJuegos = new ArrayList<>();
        ArrayList<Critica> listaCriticas = new ArrayList<>();
        ArrayList<Venta> listaVentas = new ArrayList<>();

        do {
            System.out.println("--------MENÚ--------");
            System.out.println("1. Gestionar Usuarios");
            System.out.println("2. Gestionar Marcas");
            System.out.println("3. Gestionar Consolas");
            System.out.println("4. Gestionar Juegos");
            System.out.println("5. Gestionar Críticas");
            System.out.println("6. Gestionar Ventas");
            System.out.println("7. Ver Estadísticas");
            System.out.println("8. Salir");
            System.out.println("-------------------------------------------");
            System.out.println("Introduce el número de la opción deseada:");

            int opcionMenu1 = sc.nextInt();

            switch (opcionMenu1) {
                case 1:
                    gestionarUsuarios(sc, bd, listaUsuarios);
                    break;
                case 2:
                    gestionarMarcas(sc, bd2, listaMarcas);
                    break;
                case 3:
                    gestionarConsolas(sc, bd3, listaConsolas);
                    break;
                case 4:
                    gestionarJuegos(sc, bd4, listaJuegos);
                    break;
                case 5:
                    gestionarCriticas(sc, bd5, listaCriticas);
                    break;
                case 6:
                    gestionarVentas(sc, bd6, listaVentas);
                    break;
                case 7:
                    mostrarEstadisticas();
                    break;
                case 8:
                    System.out.println("Saliendo del programa...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, introduce un número del 1 al 6.");
                    break;
            }
        } while (true);
    }

    /**
     * Método para gestionar usuarios. Permite crear, buscar, eliminar usuarios
     * y mostrar la lista de usuarios.
     *
     * @param sc Scanner para entrada de usuario.
     * @param bd Objeto UsuarioDao para realizar operaciones de base de datos.
     * @param listaUsuarios Lista de usuarios almacenados en memoria.
     */
    public static void gestionarUsuarios(Scanner sc, UsuarioDao bd, ArrayList<Usuario> listaUsuarios) {
        System.out.println("--------GESTIONAR USUARIOS--------");
        System.out.println("1. Crear usuario");
        System.out.println("2. Buscar usuario");
        System.out.println("3. Borrar usuario");
        System.out.println("4. Mostrar lista de usuarios");
        System.out.println("5. Volver al menú principal");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuUsuarios = sc.nextInt();

        switch (opcionSubMenuUsuarios) {
            case 1:

                System.out.println("Nombre Usuario: ");
                String nombreUsuario = sc.next();
                System.out.println("Correo Electronico: ");
                String correoElectronico = sc.next();
                System.out.println("Contraseña: ");
                String contrasenia = sc.next();

                Usuario u1 = new Usuario(nombreUsuario, correoElectronico, contrasenia);
                bd.create(u1);
                listaUsuarios.add(u1);
                break;
            case 2:
                System.out.println("Introduce el id del usuario que quieres consultar");
                int idConsulta = sc.nextInt();
                Usuario u2 = bd.read(idConsulta);
                if (u2 != null) {
                    System.out.println(u2);
                } else {
                    System.out.println("El usuario que quieres consultar no existe en la BD");
                }
                break;
            case 3:
                System.out.println("Introduce el id del usuario que quiere eliminar");
                int idEliminar = sc.nextInt();
                bd.delete(idEliminar);
                // Eliminar usuario de la lista si existe
                listaUsuarios.removeIf(usuario -> usuario.getId() == idEliminar);
                break;
            case 4:
                listaUsuarios = obtenerUsuariosDesdeBD();
                mostrarUsuarios(listaUsuarios);
                break;
            case 5:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para gestionar marcas. Permite crear, buscar, eliminar marcas y
     * mostrar la lista de marcas.
     *
     * @param sc Scanner para entrada de usuario.
     * @param bd Objeto MarcaDao para realizar operaciones de base de datos.
     * @param listaMarcas Lista de marcas almacenadas en memoria.
     */
    public static void gestionarMarcas(Scanner sc, MarcaDao bd, ArrayList<Marca> listaMarcas) {
        System.out.println("--------GESTIONAR MARCAS--------");
        System.out.println("1. Crear marca");
        System.out.println("2. Buscar marca");
        System.out.println("3. Borrar marca");
        System.out.println("4. Mostrar lista de marcas");
        System.out.println("5. Volver al menú principal");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuMarcas = sc.nextInt();

        switch (opcionSubMenuMarcas) {
            case 1:

                System.out.println("Nombre Marca: ");
                String nombreMarca = sc.next();

                Marca m1 = new Marca(0, nombreMarca);
                bd.create(m1);
                listaMarcas.add(m1);
                break;
            case 2:
                System.out.println("Introduce el id de la marca que quiere consultar ");
                int idMarcac = sc.nextInt();
                Marca m2 = bd.read(idMarcac);
                if (m2 != null) {
                    System.out.println(m2);
                } else {
                    System.out.println("El id de la marca introducida no existe en la BD");
                }
                break;
            case 3:
                System.out.println("Introduce el id de la marca que quiere eliminar");
                int idMarcaeliminar = sc.nextInt();
                bd.delete(idMarcaeliminar);
                // Eliminar marca de la lista si existe
                listaMarcas.removeIf(marca -> marca.getId_marca() == idMarcaeliminar);
                break;
            case 4:
                listaMarcas = obtenerMarcasDesdeBD();
                mostrarMarcas(listaMarcas);
                break;
            case 5:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para gestionar consolas. Permite crear, buscar, eliminar consolas
     * y mostrar la lista de consolas.
     *
     * @param sc Scanner para entrada de usuario.
     * @param bd Objeto ConsolaDao para realizar operaciones de base de datos.
     * @param listaConsolas Lista de consolas almacenadas en memoria.
     */
    public static void gestionarConsolas(Scanner sc, ConsolaDao bd, ArrayList<Consola> listaConsolas) {
        System.out.println("--------GESTIONAR CONSOLAS--------");
        System.out.println("1. Crear consola");
        System.out.println("2. Buscar consola");
        System.out.println("3. Borrar consola");
        System.out.println("4. Mostrar lista de consolas");
        System.out.println("5. Volver al menú principal");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuConsolas = sc.nextInt();

        switch (opcionSubMenuConsolas) {
            case 1:
                System.out.println("Nombre Consola: ");
                String nombreConsola = sc.next();
                System.out.println("Id_Marca (1-Nintendo,2-Sony,3-Sega,4-Xbox)");
                int idMarcaConsola = sc.nextInt();
                System.out.println("Es portatil? (true/false)");
                boolean portatil = sc.nextBoolean();

                Consola c1 = new Consola(nombreConsola, idMarcaConsola, portatil);
                bd.create(c1);
                listaConsolas.add(c1);
                break;
            case 2:
                System.out.println("Introduce el id de la consola que quieres consultar ");
                int idConsola2 = sc.nextInt();
                Consola con1 = bd.read(idConsola2);
                if (con1 != null) {
                    System.out.println(con1);
                } else {
                    System.out.println("El id de la consola introducida no existe en la BD");
                }
                break;
            case 3:
                System.out.println("Introduce el id de la consola que quieres eliminar");
                int idConsolaEliminar = sc.nextInt();
                bd.delete(idConsolaEliminar);
                // Eliminar consola de la lista si existe
                listaConsolas.removeIf(consola -> consola.getId() == idConsolaEliminar);
                break;
            case 4:
                listaConsolas = obtenerConsolasDesdeBD();
                mostrarConsolas(listaConsolas);
                break;
            case 5:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para gestionar juegos. Permite crear, buscar, eliminar juegos y
     * mostrar la lista de juegos.
     *
     * @param sc Scanner para entrada de usuario.
     * @param bd Objeto JuegoDao para realizar operaciones de base de datos.
     * @param listaJuegos Lista de juegos almacenados en memoria.
     */
    public static void gestionarJuegos(Scanner sc, JuegoDao bd, ArrayList<Juego> listaJuegos) {
        System.out.println("--------GESTIONAR JUEGOS--------");
        System.out.println("1. Crear videojuego");
        System.out.println("2. Buscar videojuego");
        System.out.println("3. Borrar videojuego");
        System.out.println("4. Buscar videojuegos por titulo");
        System.out.println("5. Mostrar lista de juegos");
        System.out.println("6. Volver al menú principal");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuJuegos = sc.nextInt();

        switch (opcionSubMenuJuegos) {
            case 1:
                System.out.println("Título del videojuego: ");
                String tituloJuego = sc.next();
                System.out.println("Año de lanzamiento: ");
                String anioLanzamiento = sc.next();
                System.out.println("¿Es multijugador? (true/false): ");
                boolean multijugador = sc.nextBoolean();
                System.out.println("Precio del juego: ");
                double precioJuego = sc.nextDouble();
                System.out.println("ID de la consola asociada:(Del 1 al 20)");
                int idConsolaJuego = sc.nextInt();

                Juego juegoNuevo = new Juego(0, tituloJuego, anioLanzamiento, multijugador, precioJuego, idConsolaJuego);
                bd.create(juegoNuevo);
                listaJuegos.add(juegoNuevo);
                break;
            case 2:
                sc.nextLine();
                System.out.println("Introduce el titulo del videojuego que quieres ver");
                String nombreJuego = sc.nextLine();
                Juego j1 = bd.read(nombreJuego);
                if (j1 != null) {
                    System.out.println(j1);
                } else {
                    System.out.println("El juego introducido no existe en la BD");
                }
                break;
            case 3:
                System.out.println("ID del juego a borrar:");
                int idJuegoBorrar = sc.nextInt();
                bd.delete(idJuegoBorrar);
                // Eliminar juego de la lista si existe
                listaJuegos.removeIf(juego -> juego.getId() == idJuegoBorrar);
                break;
            case 4:
                listaJuegos = obtenerVideojuegosDesdeBD();
                sc.nextLine();
                System.out.println("Introduce las primeras tres letras del título del videojuego o una palabra clave:");
                String busquedaTitulo = sc.nextLine();
                ArrayList<Juego> juegosEncontrados = buscarJuegosPorTitulo(busquedaTitulo, listaJuegos, bd);
                if (juegosEncontrados.isEmpty()) {
                    System.out.println("No se encontraron juegos que coincidan con la búsqueda.");
                } else {
                    System.out.println("Se encontraron los siguientes juegos:");
                    mostrarJuegos(juegosEncontrados);
                }
                break;
            case 5:
                listaJuegos = obtenerVideojuegosDesdeBD();
                mostrarJuegos(listaJuegos);
                break;
            case 6:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para gestionar críticas. Permite crear, buscar, eliminar críticas
     * y mostrar la lista de críticas.
     *
     * @param sc Scanner para entrada de usuario.
     * @param bd Objeto CriticaDao para realizar operaciones de base de datos.
     * @param listaCriticas Lista de críticas almacenadas en memoria.
     */
    public static void gestionarCriticas(Scanner sc, CriticaDao bd, ArrayList<Critica> listaCriticas) {
        System.out.println("--------GESTIONAR CRÍTICAS--------");
        System.out.println("1. Crear crítica");
        System.out.println("2. Buscar crítica");
        System.out.println("3. Borrar crítica");
        System.out.println("4. Mostrar lista de críticas");
        System.out.println("5. Volver al menú principal");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuCriticas = sc.nextInt();

        switch (opcionSubMenuCriticas) {
            case 1:
                System.out.println("ID del juego: ");
                int idJuego = sc.nextInt();
                System.out.println("ID del usuario: ");
                int idUsuario = sc.nextInt();
                System.out.println("Puntuación: ");
                int puntuacion = sc.nextInt();
                System.out.println("Comentario: ");
                String comentario = sc.nextLine(); // Para leer el salto de línea pendiente
                comentario = sc.nextLine(); // Lee la línea de comentario
                System.out.println("Fecha de la crítica (formato: yyyy-mm-dd): ");
                String fechaCriticaStr = sc.next();
                Date fechaCritica = Date.valueOf(fechaCriticaStr);

                Critica criticaNueva = new Critica(0, idJuego, idUsuario, puntuacion, comentario, fechaCritica);
                bd.create(criticaNueva);
                listaCriticas.add(criticaNueva);
                break;
            case 2:
                System.out.println("Introduce el id de la crítica que quieres consultar ");
                int idCritica = sc.nextInt();
                Critica critica = bd.read(idCritica);
                if (critica != null) {
                    System.out.println(critica);
                } else {
                    System.out.println("La crítica con el id introducido no existe en la BD");
                }
                break;
            case 3:
                System.out.println("ID de la crítica a borrar:");
                int idCriticaBorrar = sc.nextInt();
                bd.delete(idCriticaBorrar);
                // Eliminar crítica de la lista si existe

                break;
            case 4:
                listaCriticas = obtenerCriticasDesdeBD();
                mostrarCriticas(listaCriticas);
                break;
            case 5:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para gestionar ventas. Permite registrar, buscar, eliminar ventas
     * y mostrar la lista de ventas.
     *
     * @param sc Scanner para entrada de usuario.
     * @param ventaDao Objeto VentaDao para realizar operaciones de base de
     * datos.
     * @param listaVentas Lista de ventas almacenadas en memoria.
     */
    public static void gestionarVentas(Scanner sc, VentaDao ventaDao, ArrayList<Venta> listaVentas) {
        System.out.println("--------GESTIONAR VENTAS--------");
        System.out.println("1. Registrar nueva venta");
        System.out.println("2. Buscar venta");
        System.out.println("3. Eliminar venta");
        System.out.println("4. Mostrar lista de ventas");
        System.out.println("5. Volver al menú principal");
        System.out.println("---------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        int opcionSubMenuVentas = sc.nextInt();

        switch (opcionSubMenuVentas) {
            case 1:
                System.out.println("ID del juego: ");
                int idJuego = sc.nextInt();
                System.out.println("Cantidad: ");
                int cantidad = sc.nextInt();
                System.out.println("Fecha de la venta (formato: yyyy-mm-dd): ");
                String fechaVentaStr = sc.next();
                Date fechaVenta = Date.valueOf(fechaVentaStr);

                Venta nuevaVenta = new Venta(0, idJuego, cantidad, fechaVenta);
                ventaDao.create(nuevaVenta);
                listaVentas.add(nuevaVenta);
                break;
            case 2:
                System.out.println("Introduce el id de la venta que quieres consultar ");
                int idVenta = sc.nextInt();
                Venta venta = ventaDao.read(idVenta);
                if (venta != null) {
                    System.out.println(venta);
                } else {
                    System.out.println("La venta con el id introducido no existe en la BD");
                }
                break;
            case 3:
                System.out.println("ID de la venta a eliminar:");
                int idVentaEliminar = sc.nextInt();
                ventaDao.delete(idVentaEliminar);
                // Eliminar venta de la lista si existe

                break;
            case 4:
                listaVentas = obtenerVentasDesdeBD();
                mostrarVentas(listaVentas);
                break;
            case 5:
                System.out.println("Volviendo al menú principal...");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 5.");
                break;
        }
    }

    /**
     * Método para mostrar usuarios.
     *
     * @param listaUsuario Lista de usuarios a mostrar.
     */
    public static void mostrarUsuarios(ArrayList<Usuario> listaUsuario) {
        for (Usuario usuario : listaUsuario) {
            System.out.println(usuario);
        }
    }

    /**
     * Método para mostrar marcas.
     *
     * @param listaMarcas Lista de marcas a mostrar.
     */
    public static void mostrarMarcas(ArrayList<Marca> listaMarcas) {
        for (Marca marca : listaMarcas) {
            System.out.println(marca);
        }
    }

    /**
     * Método para mostrar consolas.
     *
     * @param listaConsolas Lista de consolas a mostrar.
     */
    public static void mostrarConsolas(ArrayList<Consola> listaConsolas) {
        for (Consola consola : listaConsolas) {
            System.out.println(consola);
        }
    }

    /**
     * Método para mostrar juegos.
     *
     * @param listaJuegos Lista de juegos a mostrar.
     */
    public static void mostrarJuegos(ArrayList<Juego> listaJuegos) {
        for (Juego juego : listaJuegos) {
            System.out.println(juego);
        }
    }

    /**
     * Método para mostrar críticas.
     *
     * @param listaCriticas Lista de críticas a mostrar.
     */
    public static void mostrarCriticas(ArrayList<Critica> listaCriticas) {
        for (Critica critica : listaCriticas) {
            System.out.println(critica);
        }
    }

    /**
     * Método para mostrar ventas.
     *
     * @param listaVentas Lista de ventas a mostrar.
     */
    public static void mostrarVentas(ArrayList<Venta> listaVentas) {
        for (Venta venta : listaVentas) {
            System.out.println(venta);
        }
    }

    /**
     * Método para obtener usuarios desde la base de datos.
     *
     * @return Lista de usuarios obtenida desde la base de datos.
     */
    public static ArrayList<Usuario> obtenerUsuariosDesdeBD() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery("SELECT * FROM usuarios")) {
            while (rs.next()) {
                // Obtener los datos de la fila actual
                int id = rs.getInt("id_usuario");
                String nombreUsuario = rs.getString("nombre_usuario");
                String correoElectronico = rs.getString("correo_electronico");
                String contrasenia = rs.getString("contrasena");

                // Crear un objeto Usuario y agregarlo a la lista
                Usuario usuario = new Usuario(id, nombreUsuario, correoElectronico, contrasenia);
                usuarios.add(usuario);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener usuarios de la BD");
        }
        return usuarios;
    }

    /**
     * Método para obtener marcas desde la base de datos.
     *
     * @return Lista de marcas obtenida desde la base de datos.
     */
    public static ArrayList<Marca> obtenerMarcasDesdeBD() {
        ArrayList<Marca> marcas = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery("SELECT * FROM marcas")) {
            while (rs.next()) {
                // Obtener los datos de la fila actual
                int id = rs.getInt("id_marca");
                String nombre = rs.getString("nombre_marca");

                // Crear un objeto Marca y agregarlo a la lista
                Marca marca = new Marca(id, nombre);
                marcas.add(marca);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener marcas de la BD");
        }
        return marcas;
    }

    /**
     * Método para obtener consolas desde la base de datos.
     *
     * @return Lista de consolas obtenida desde la base de datos.
     */
    public static ArrayList<Consola> obtenerConsolasDesdeBD() {
        ArrayList<Consola> consolas = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery("SELECT * FROM Consolas")) {
            while (rs.next()) {
                // Obtener los datos de la fila actual
                int id = rs.getInt("id_consola");
                String nombre = rs.getString("nombre_consola");
                int idMarca = rs.getInt("id_marca");
                boolean portatil = rs.getBoolean("portatil");

                // Crear un objeto Consola y agregarlo a la lista
                Consola consola = new Consola(id, nombre, idMarca, portatil);
                consolas.add(consola);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener consolas de la BD");
        }
        return consolas;
    }

    /**
     * Método para obtener videojuegos desde la base de datos.
     *
     * @return Lista de videojuegos obtenida desde la base de datos.
     */
    public static ArrayList<Juego> obtenerVideojuegosDesdeBD() {
        ArrayList<Juego> videojuegos = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery("SELECT * FROM Juegos")) {

            while (rs.next()) {
                // Obtener los datos de la fila actual
                int id = rs.getInt("id_juego");
                String titulo = rs.getString("titulo");
                String anioLanzamiento = rs.getString("anio_lanzamiento");
                //Aplicamos substr para que solo muestre el año de lanzamiento
                if (anioLanzamiento != null && anioLanzamiento.length() >= 4) {
                    anioLanzamiento = anioLanzamiento.substring(0, 4);
                }
                boolean multijugador = rs.getBoolean("multijugador");
                double precio = rs.getDouble("precio");
                int idConsola = rs.getInt("id_consola");

                // Crear un objeto Juego y agregarlo a la lista
                Juego juego = new Juego(id, titulo, anioLanzamiento, multijugador, precio, idConsola);
                videojuegos.add(juego);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener videojuegos de la BD");
        }
        return videojuegos;
    }

    /**
     * Método para obtener críticas desde la base de datos.
     *
     * @return Lista de críticas obtenida desde la base de datos.
     */
    public static ArrayList<Critica> obtenerCriticasDesdeBD() {
        ArrayList<Critica> criticas = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery("SELECT * FROM Criticas")) {
            while (rs.next()) {
                // Obtener los datos de la fila actual
                int idCritica = rs.getInt("id_critica");
                int idJuego = rs.getInt("id_juego");
                int idUsuario = rs.getInt("id_usuario");
                int puntuacion = rs.getInt("puntuacion");
                String comentario = rs.getString("comentario");
                Date fechaCritica = rs.getDate("fecha_critica");

                // Crear un objeto Critica y agregarlo a la lista
                Critica critica = new Critica(idCritica, idJuego, idUsuario, puntuacion, comentario, fechaCritica);
                criticas.add(critica);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener críticas de la BD: " + e.getMessage());
        }
        return criticas;
    }

    /**
     * Método para obtener ventas desde la base de datos.
     *
     * @return Lista de ventas obtenida desde la base de datos.
     */
    public static ArrayList<Venta> obtenerVentasDesdeBD() {
        ArrayList<Venta> ventas = new ArrayList<>();
        String sql = "SELECT * FROM Ventas";
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root");  Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int idVenta = rs.getInt("id_venta");
                int idJuego = rs.getInt("id_juego");
                int cantidad = rs.getInt("cantidad");
                Date fechaVenta = rs.getDate("fecha_venta");
                Venta venta = new Venta(idVenta, idJuego, cantidad, fechaVenta);
                ventas.add(venta);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener ventas de la BD: " + e.getMessage());
        }
        return ventas;
    }

    /**
     * Método para buscar juegos por título.
     *
     * @param busqueda Título del juego a buscar.
     * @param listaJuegos Lista de juegos en la que buscar.
     * @param juegoDao Objeto JuegoDao para realizar operaciones de base de
     * datos.
     * @return Lista de juegos encontrados.
     */
    public static ArrayList<Juego> buscarJuegosPorTitulo(String busqueda, ArrayList<Juego> listaJuegos, JuegoDao juegoDao) {
        ArrayList<Juego> juegosEncontrados = new ArrayList<>();
        ArrayList<Juego> juegosDeLaBaseDeDatos = juegoDao.read2(busqueda);

        for (Juego juegoDeBD : juegosDeLaBaseDeDatos) {
            boolean encontrado = false;
            for (Juego juegoEncontrado : juegosEncontrados) {
                if (juegoEncontrado.getId() == juegoDeBD.getId()) {
                    encontrado = true;
                    break;
                }
            }
            // Si el juego encontrado no está en la lista, agrégalo
            if (!encontrado) {
                juegosEncontrados.add(juegoDeBD);
            }
        }
        return juegosEncontrados;
    }

    /**
     * Método para mostrar estadísticas. Los joins y demas procedimientos estan
     * incluidos en la carpeta del trabajo en un script llamado joins.txt
     */
    public static void mostrarEstadisticas() {
        System.out.println("--------ESTADÍSTICAS--------");
        System.out.println("1. Juegos junto con la consola y la marca");
        System.out.println("2. Juegos juegos vendidos, nombre de la marca y comentario");
        System.out.println("3. Juegos con precio superior al precio promedio (39€)");
        System.out.println("4. Número de ventas y total de ventas por juego");
        System.out.println("5. Críticas de los juegos con el nombre del usuario");
        System.out.println("6. Ventas de juegos con título y fecha de venta");
        System.out.println("7. Juegos multijugador con su consola");
        System.out.println("8. Cantidad total de ventas por juego");
        System.out.println("9. Total de ventas por año");
        System.out.println("-----------------------------------");
        System.out.println("Introduce el número de la opción deseada:");

        Scanner sc = new Scanner(System.in);
        int opcionEstadisticas = sc.nextInt();

        switch (opcionEstadisticas) {
            case 1:
                mostrarConsulta("SELECT J.titulo AS juego, C.nombre_consola AS consola, M.nombre_marca AS marca"
                        + "FROM Juegos J"
                        + "INNER JOIN Consolas C ON J.id_consola = C.id_consola"
                        + "INNER JOIN Marcas M ON C.id_marca = M.id_marca;");
                break;
            case 2:
                mostrarConsulta("SELECT J.titulo AS juego, M.nombre_marca AS marca, C.comentario"
                        + "FROM Juegos J"
                        + "INNER JOIN Ventas V ON J.id_juego = V.id_juego"
                        + "INNER JOIN Consolas CO ON J.id_consola = CO.id_consola"
                        + "INNER JOIN Marcas M ON CO.id_marca = M.id_marca"
                        + "INNER JOIN Criticas C ON J.id_juego = C.id_juego;");
                break;
            case 3:
                mostrarConsulta("SELECT titulo, precio"
                        + "FROM Juegos"
                        + "WHERE precio > (SELECT AVG(precio) FROM Juegos);");
                break;
            case 4:
                mostrarConsulta("SELECT J.titulo, COUNT(*) AS ventas, SUM(V.cantidad) AS total_ventas "
                        + "FROM Ventas V "
                        + "INNER JOIN Juegos J ON V.id_juego = J.id_juego "
                        + "GROUP BY J.titulo;");
                break;
            case 5:
                mostrarConsulta("SELECT C.comentario, J.titulo, U.nombre_usuario "
                        + "FROM Criticas C "
                        + "INNER JOIN Usuarios U ON C.id_usuario = U.id_usuario "
                        + "INNER JOIN Juegos J ON C.id_juego = J.id_juego;");
                break;
            case 6:
                mostrarConsulta("SELECT V.fecha_venta, J.titulo, V.cantidad "
                        + "FROM Ventas V "
                        + "INNER JOIN Juegos J ON V.id_juego = J.id_juego;");
                break;
            case 7:
                mostrarConsulta("SELECT J.titulo, J.multijugador, C.nombre_consola "
                        + "FROM Juegos J "
                        + "INNER JOIN Consolas C ON J.id_consola = C.id_consola "
                        + "WHERE J.multijugador = TRUE;");
                break;
            case 8:
                mostrarConsulta("SELECT J.titulo, SUM(V.cantidad) AS total_ventas "
                        + "FROM Juegos J "
                        + "INNER JOIN Ventas V ON J.id_juego = V.id_juego "
                        + "GROUP BY J.titulo;");
                break;
            case 9:
                mostrarConsulta("CALL TotalVentasPorAnio();");
                break;
            default:
                System.out.println("Opción no válida. Por favor, introduce un número del 1 al 9.");
                break;
        }
    }

    /**
     * Método para mostrar resultados de una consulta.
     *
     * @param consulta Consulta SQL a ejecutar.
     */
    public static void mostrarConsulta(String consulta) {
        try ( Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/TiendaVideojuegos", "root", "root"); 
              
            Statement stmt = conn.createStatement();  ResultSet rs = stmt.executeQuery(consulta)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(metaData.getColumnLabel(i) + ": " + rs.getString(i) + "\t");
                }
                System.out.println(); // Agregar una nueva línea después de imprimir todos los campos de una fila
            }
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
    }

}
