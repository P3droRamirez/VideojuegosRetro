/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

/**
 * * Clase que representa una consola de videojuegos.
 * Una consola tiene un identificador único, un nombre, una marca asociada y un indicador de si es portátil o no.
 * 
 * @author pedro
 */
public class Consola {
    private final int TAM_NOMBRE = 50;
    private int id;
    private String nombre_consola;
    private int id_marca;
    private boolean portatil;

    /**
     * Constructor de la clase Consola que recibe el identificador de la consola.
     * 
     * @param id Identificador único de la consola.
     */
    public Consola(int id) {
        this.id = id;
    }
    
    /**
     * Constructor de la clase Consola que recibe el nombre, el identificador de la marca y el indicador de portabilidad.
     * 
     * @param nombre_consola Nombre de la consola.
     * @param id_marca Identificador de la marca de la consola.
     * @param portatil Indica si la consola es portátil o no.
     */

    public Consola(String nombre_consola, int id_marca, boolean portatil) {
        this.nombre_consola = nombre_consola;
        this.id_marca = id_marca;
        this.portatil = portatil;
    }

    /**
     * Constructor de la clase Consola que recibe el identificador, el nombre, el identificador de la marca y el indicador de portabilidad.
     * 
     * @param id Identificador único de la consola.
     * @param nombre_consola Nombre de la consola.
     * @param id_marca Identificador de la marca de la consola.
     * @param portatil Indica si la consola es portátil o no.
     */
    
    public Consola(int id, String nombre_consola, int id_marca, boolean portatil) {
        this.id = id;
        this.nombre_consola = nombre_consola;
        this.id_marca = id_marca;
        this.portatil = portatil;
    }
    
      // Métodos de acceso (getters y setters)
    
    /**
     * Obtiene el identificador único de la consola.
     * 
     * @return El identificador único de la consola.
     */

    public int getId() {
        return id;
    }
/**
     * Establece el identificador único de la consola.
     * 
     * @param id El identificador único de la consola.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre de la consola.
     * 
     * @return El nombre de la consola.
     */
    public String getNombre_consola() {
        return nombre_consola;
    }

    /**
     * Establece el nombre de la consola.
     * 
     * @param nombre_consola El nombre de la consola.
     */
    public void setNombre_consola(String nombre_consola) {
        this.nombre_consola = nombre_consola;
    }

    /**
     * Obtiene el identificador de la marca de la consola.
     * 
     * @return El identificador de la marca de la consola.
     */
    public int getId_marca() {
        return id_marca;
    }

    /**
     * Establece el identificador de la marca de la consola.
     * 
     * @param id_marca El identificador de la marca de la consola.
     */
    public void setId_marca(int id_marca) {
        this.id_marca = id_marca;
    }

    /**
     * Comprueba si la consola es portátil o no.
     * 
     * @return true si la consola es portátil, false en caso contrario.
     */
    public boolean isPortatil() {
        return portatil;
    }

    /**
     * Establece si la consola es portátil o no.
     * 
     * @param portatil Indica si la consola es portátil o no.
     */
    public void setPortatil(boolean portatil) {
        this.portatil = portatil;
    }

    /**
     * Devuelve una representación en cadena de caracteres de la consola.
     * 
     * @return Cadena de caracteres que representa la consola.
     */
    @Override
    public String toString() {
        return "Consola{" + "id=" + id + ", nombre_consola=" + nombre_consola + ", id_marca=" + id_marca + ", portatil=" + portatil + '}';
    }  
}