/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

/**
 * La clase Usuario representa a un usuario de la tienda de videojuegos.
 * 
 * Contiene información como el nombre de usuario, correo electrónico y contraseña.
 * 
 * @author pedro
 */
public class Usuario {
    
    private final int TAM_NOMBRE = 50;
    private final int TAM_CORREO = 100;
    private final int TAM_CONTRASENA = 100;
    private int id;
    private String nombre_usuario;
    private String correo_electronico;
    private String contrasena;

    /**
     * Constructor de la clase Usuario que toma un ID como parámetro.
     * 
     * @param id El ID del usuario.
     */
    public Usuario(int id) {
        this.id = id;
    }

    /**
     * Constructor de la clase Usuario que toma el nombre de usuario, correo electrónico y contraseña como parámetros.
     * 
     * @param nombre_usuario El nombre del usuario.
     * @param correo_electronico El correo electrónico del usuario.
     * @param contrasena La contraseña del usuario.
     */
    public Usuario(String nombre_usuario, String correo_electronico, String contrasena) {
        this.nombre_usuario = nombre_usuario;
        this.correo_electronico = correo_electronico;
        this.contrasena = contrasena;
    }
    

    /**
     * Constructor de la clase Usuario que toma un ID, el nombre de usuario, correo electrónico y contraseña como parámetros.
     * 
     * @param id El ID del usuario.
     * @param nombre_usuario El nombre del usuario.
     * @param correo_electronico El correo electrónico del usuario.
     * @param contrasena La contraseña del usuario.
     */
    public Usuario(int id, String nombre_usuario, String correo_electronico, String contrasena) {
        this.id = id;
        this.nombre_usuario = nombre_usuario;
        this.correo_electronico = correo_electronico;
        this.contrasena = contrasena;
    }

    /**
     * Obtiene el ID del usuario.
     * 
     * @return El ID del usuario.
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el ID del usuario.
     * 
     * @param id El ID del usuario.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el nombre de usuario.
     * 
     * @return El nombre de usuario.
     */
    public String getNombre_usuario() {
        return nombre_usuario;
    }

    /**
     * Establece el nombre de usuario.
     * 
     * @param nombre_usuario El nombre de usuario.
     */
    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    /**
     * Obtiene el correo electrónico del usuario.
     * 
     * @return El correo electrónico del usuario.
     */
    public String getCorreo_electronico() {
        return correo_electronico;
    }

    /**
     * Establece el correo electrónico del usuario.
     * 
     * @param correo_electronico El correo electrónico del usuario.
     */
    public void setCorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }

    /**
     * Obtiene la contraseña del usuario.
     * 
     * @return La contraseña del usuario.
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * Establece la contraseña del usuario.
     * 
     * @param contrasena La contraseña del usuario.
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    /**
     * Retorna una representación en cadena del objeto Usuario.
     * 
     * @return Una cadena que representa al objeto Usuario.
     */
    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", nombre_usuario=" + nombre_usuario + ", correo_electronico=" + correo_electronico + ", contrasena=" + contrasena + '}';
    }
}
