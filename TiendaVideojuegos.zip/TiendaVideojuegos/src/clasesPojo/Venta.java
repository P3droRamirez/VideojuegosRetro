/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

import java.sql.Date;

/**
 * La clase Venta representa una transacción de venta de un juego en la tienda.
 * Contiene información sobre el ID de la venta, el ID del juego vendido, la cantidad vendida y la fecha de la venta.
 * 
 * @author pedro
 */
public class Venta {
    private int id_venta; // ID de la venta
    private int id_juego; // ID del juego vendido
    private int cantidad; // Cantidad vendida
    private Date fecha_venta; // Fecha de la venta

    /**
     * Constructor de la clase Venta que inicializa los atributos.
     * 
     * @param id_juego El ID del juego vendido.
     * @param cantidad La cantidad vendida.
     * @param fecha_venta La fecha de la venta.
     */
    public Venta(int id_juego, int cantidad, Date fecha_venta) {
        this.id_juego = id_juego;
        this.cantidad = cantidad;
        this.fecha_venta = fecha_venta;
    }

    /**
     * Constructor de la clase Venta que inicializa todos los atributos.
     * 
     * @param id_venta El ID de la venta.
     * @param id_juego El ID del juego vendido.
     * @param cantidad La cantidad vendida.
     * @param fecha_venta La fecha de la venta.
     */
    public Venta(int id_venta, int id_juego, int cantidad, Date fecha_venta) {
        this.id_venta = id_venta;
        this.id_juego = id_juego;
        this.cantidad = cantidad;
        this.fecha_venta = fecha_venta;
    }

    // Métodos getter y setter para los atributos de la clase

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }

    public int getId_juego() {
        return id_juego;
    }

    public void setId_juego(int id_juego) {
        this.id_juego = id_juego;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Date getFecha_venta() {
        return fecha_venta;
    }

    public void setFecha_venta(Date fecha_venta) {
        this.fecha_venta = fecha_venta;
    }

    /**
     * Método toString para imprimir información sobre la venta.
     * 
     * @return Una cadena que representa la venta.
     */
    @Override
    public String toString() {
        return "Venta{" +
                "id_venta=" + id_venta +
                ", id_juego=" + id_juego +
                ", cantidad=" + cantidad +
                ", fecha_venta=" + fecha_venta +
                '}';
    }
}
