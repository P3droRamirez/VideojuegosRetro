/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

/**
 * Representa una marca de consola en el sistema.
 * Cada marca tiene un identificador único y un nombre.
 * Esta clase proporciona métodos para acceder y modificar los datos de una marca.
 * 
 * @author pedro
 */
public class Marca {
    private final int TAM_NOMBRE = 50; // Tamaño máximo del nombre de la marca
    private int id_marca; // Identificador de la marca
    private String nombre_marca; // Nombre de la marca

    /**
     * Constructor de la clase Marca con el identificador de la marca.
     * 
     * @param id_marca El identificador único de la marca.
     */
    public Marca(int id_marca) {
        this.id_marca = id_marca;
    }

    /**
     * Constructor de la clase Marca con el identificador y el nombre de la marca.
     * 
     * @param id_marca El identificador único de la marca.
     * @param nombre_marca El nombre de la marca.
     */
    public Marca(int id_marca, String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    /**
     * Obtiene el identificador único de la marca.
     * 
     * @return El identificador único de la marca.
     */
    public int getId_marca() {
        return id_marca;
    }

    /**
     * Establece el identificador único de la marca.
     * 
     * @param id_marca El identificador único de la marca.
     */
    public void setId_marca(int id_marca) {
        this.id_marca = id_marca;
    }

    /**
     * Obtiene el nombre de la marca.
     * 
     * @return El nombre de la marca.
     */
    public String getNombre_marca() {
        return nombre_marca;
    }

    /**
     * Establece el nombre de la marca.
     * 
     * @param nombre_marca El nombre de la marca.
     */
    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    /**
     * Devuelve una representación en cadena de la marca, que incluye su identificador y nombre.
     * 
     * @return Una cadena que representa la marca.
     */
    @Override
    public String toString() {
        return "Marca{" + "id_marca=" + id_marca + ", nombre_marca=" + nombre_marca + '}';
    }
}
