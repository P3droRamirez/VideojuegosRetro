/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Consola;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase proporciona métodos para realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) sobre la tabla de consolas en la base de datos.
 * Utiliza la clase Consola del paquete clasesPojo para representar los datos de las consolas.
 * La conexión a la base de datos se establece mediante JDBC.
 * 
 * @author pedro
 */
public class ConsolaDao {
    private Connection conexion; // Conexión a la base de datos
    private final String USUARIO = "root"; // Nombre de usuario de la base de datos
    private final String PASSWORD = "root"; // Contraseña de la base de datos
    private final String MAQUINA = "localhost"; // Nombre de la máquina donde se encuentra la base de datos
    private final String BD = "TiendaVideojuegos"; // Nombre de la base de datos
    
    /**
     * Constructor de la clase ConsolaDao. Establece la conexión a la base de datos al crear una instancia de la clase.
     */
    public ConsolaDao() {
        conexion = conectar();
    }

    /**
     * Establece la conexión a la base de datos.
     * 
     * @return La conexión a la base de datos.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD");
        }
        return con;
    }
    
    /**
     * Inserta una nueva consola en la base de datos.
     * 
     * @param consola La consola a insertar.
     */
    public void create(Consola consola) {
        if (consola != null) {
            String sql = "INSERT INTO Consolas(nombre_consola,id_marca,portatil) "
                    + "VALUES(?, ?, ?)";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                
                sentencia.setString(1, consola.getNombre_consola());
                sentencia.setInt(2, consola.getId_marca());
                sentencia.setBoolean(3, consola.isPortatil());
                sentencia.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Error al insertar");
            }
        }
    }
    
    /**
     * Lee una consola de la base de datos según su identificador.
     * 
     * @param id El identificador de la consola a leer.
     * @return La consola encontrada, o null si no se encontró ninguna consola con el identificador especificado.
     */
    public Consola read(int id) {
        Consola consola = null;
        String sql = "SELECT * FROM Consolas WHERE id_consola=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            ResultSet rs = sentencia.executeQuery();

            if (rs.next()) {//Si existe registro
                String nombre = rs.getString("nombre_consola");
                int marca = rs.getInt("id_marca");
                boolean portatil = rs.getBoolean("portatil");
                
                consola = new Consola(id, nombre,marca,portatil);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar un usuario");
        }
        return consola;
    }
    
    /**
     * Actualiza los datos de una consola en la base de datos.
     * 
     * @param consola La consola con los datos actualizados.
     */
    public void update(Consola consola) {
        if (consola != null) {
            String sql = "UPDATE Consolas SET nombre_consola=?, id_marca=?, portatil=? WHERE id_consola=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, consola.getNombre_consola());;
                sentencia.setInt(2, consola.getId_marca());
                sentencia.setBoolean(3, consola.isPortatil());
                sentencia.setInt(4, consola.getId());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al actualizar una marca");
            }
        }
    }
    
    /**
     * Elimina una consola de la base de datos según su identificador.
     * 
     * @param id El identificador de la consola a eliminar.
     */
    public void delete(int id) {
        String sql = "DELETE FROM Consolas WHERE id_consola = ?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            sentencia.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al eliminar al usuario");
        }
    }
}
