/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Venta;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * La clase VentaDao proporciona métodos para interactuar con la base de datos en relación con las ventas de juegos.
 * Permite realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) sobre la tabla Ventas en la base de datos TiendaVideojuegos.
 * 
 * @author pedro
 */
public class VentaDao {
    private Connection conexion; // Objeto de conexión a la base de datos
    private final String USUARIO = "root"; // Nombre de usuario de la base de datos
    private final String PASSWORD = "root"; // Contraseña de la base de datos
    private final String MAQUINA = "localhost"; // Dirección IP o nombre del servidor de la base de datos
    private final String BD = "TiendaVideojuegos"; // Nombre de la base de datos

    /**
     * Constructor de la clase VentaDao que establece la conexión a la base de datos.
     */
    public VentaDao() {
        conexion = conectar();
    }

    /**
     * Método para establecer la conexión a la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD; // URL de conexión a la base de datos
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD); // Intenta establecer la conexión
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD: " + e.getMessage()); // Imprime el mensaje de error si la conexión falla
        }
        return con;
    }

    /**
     * Método para crear una nueva venta en la base de datos.
     * 
     * @param venta La venta a ser creada.
     */
    public void create(Venta venta) {
        if (venta != null) {
            String sql = "INSERT INTO Ventas (id_juego, cantidad, fecha_venta) VALUES (?, ?, ?)"; // Consulta SQL para insertar una nueva venta
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql); // Prepara la sentencia SQL
                sentencia.setInt(1, venta.getId_juego()); // Establece el ID del juego vendido
                sentencia.setInt(2, venta.getCantidad()); // Establece la cantidad vendida
                sentencia.setDate(3, venta.getFecha_venta()); // Establece la fecha de la venta
                sentencia.executeUpdate(); // Ejecuta la sentencia SQL para insertar la venta en la base de datos
            } catch (SQLException e) {
                System.out.println("Error al insertar venta: " + e.getMessage()); // Imprime el mensaje de error si la operación falla
            }
        }
    }

    /**
     * Método para leer una venta de la base de datos por su ID.
     * 
     * @param id El ID de la venta a leer.
     * @return La venta leída, o null si no se encuentra.
     */
    public Venta read(int id) {
        Venta venta = null; // Inicializa la venta como null
        String sql = "SELECT * FROM Ventas WHERE id_venta=?"; // Consulta SQL para seleccionar una venta por su ID
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql); // Prepara la sentencia SQL
            sentencia.setInt(1, id); // Establece el ID de la venta en la consulta
            ResultSet rs = sentencia.executeQuery(); // Ejecuta la consulta y obtiene los resultados

            if (rs.next()) { // Si hay resultados
                int id_juego = rs.getInt("id_juego"); // Obtiene el ID del juego vendido
                int cantidad = rs.getInt("cantidad"); // Obtiene la cantidad vendida
                java.sql.Date fecha_venta = rs.getDate("fecha_venta"); // Obtiene la fecha de la venta
                venta = new Venta(id, id_juego, cantidad, fecha_venta); // Crea un objeto Venta con los datos obtenidos
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar venta: " + e.getMessage()); // Imprime el mensaje de error si la operación falla
        }
        return venta; // Devuelve la venta leída
    }

    /**
     * Método para actualizar una venta en la base de datos.
     * 
     * @param venta La venta a ser actualizada.
     */
    public void update(Venta venta) {
        if (venta != null) {
            String sql = "UPDATE Ventas SET id_juego=?, cantidad=?, fecha_venta=? WHERE id_venta=?"; // Consulta SQL para actualizar una venta
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql); // Prepara la sentencia SQL
                sentencia.setInt(1, venta.getId_juego()); // Establece el ID del juego vendido
                sentencia.setInt(2, venta.getCantidad()); // Establece la cantidad vendida
                sentencia.setDate(3, venta.getFecha_venta()); // Establece la fecha de la venta
                sentencia.setInt(4, venta.getId_venta()); // Establece el ID de la venta en la cláusula WHERE
                sentencia.executeUpdate(); // Ejecuta la sentencia SQL para actualizar la venta en la base de datos
            } catch (SQLException e) {
                System.out.println("Error al actualizar venta: " + e.getMessage()); // Imprime el mensaje de error si la operación falla
            }
        }
    }

    /**
     * Método para eliminar una venta de la base de datos por su ID.
     * 
     * @param id El ID de la venta a ser eliminada.
     */
    public void delete(int id) {
        String sql = "DELETE FROM Ventas WHERE id_venta=?"; // Consulta SQL para eliminar una venta por su ID
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql); // Prepara la sentencia SQL
            sentencia.setInt(1, id); // Establece el ID de la venta en la consulta
            sentencia.executeUpdate(); // Ejecuta la sentencia SQL para eliminar la venta de la base de datos
        } catch (SQLException e) {
            System.out.println("Error al eliminar venta: " + e.getMessage()); // Imprime el mensaje de error si la operación falla
        }
    }
}
