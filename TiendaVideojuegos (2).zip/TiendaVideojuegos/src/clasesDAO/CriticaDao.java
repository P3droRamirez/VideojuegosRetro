/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Critica;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Esta clase proporciona métodos para realizar operaciones CRUD en la tabla de críticas de la base de datos TiendaVideojuegos.
 * 
 * Nota: Asegúrate de manejar correctamente las excepciones y los recursos en cada método para evitar problemas de seguridad y fugas de recursos.
 * Además, considera refactorizar el código para mejorar la eficiencia y la legibilidad.
 * 
 * @author pedro
 */
public class CriticaDao {

    private Connection conexion;
    private final String USUARIO = "root";
    private final String PASSWORD = "root";
    private final String MAQUINA = "localhost";
    private final String BD = "TiendaVideojuegos";
    private final String URL = "jdbc:mysql://localhost/TiendaVideojuegos";

    /**
     * Constructor de la clase CriticaDao. Establece la conexión con la base de datos.
     */
    public CriticaDao() {
        conexion = conectar();
    }

    /**
     * Método privado para establecer la conexión con la base de datos.
     * 
     * @return La conexión establecida con la base de datos.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD");
        }
        return con;
    }

    /**
     * Método para agregar una nueva crítica a la base de datos.
     * 
     * @param critica La crítica que se va a agregar.
     */
    public void create(Critica critica) {
        try ( Connection conn = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String sql = "INSERT INTO Criticas (id_juego, id_usuario, puntuacion, comentario, fecha_critica) VALUES (?, ?, ?, ?, ?)";
            try ( PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, critica.getIdJuego());
                pstmt.setInt(2, critica.getIdUsuario());
                pstmt.setInt(3, critica.getPuntuacion());
                pstmt.setString(4, critica.getComentario());
                pstmt.setDate(5, new java.sql.Date(critica.getFechaCritica().getTime())); // Convertir Date a java.sql.Date
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Error al agregar la crítica: " + e.getMessage());
        }
    }
    
    /**
     * Método para obtener todas las críticas de un juego específico.
     * 
     * @param idJuego El ID del juego del cual se desean obtener las críticas.
     * @return Una lista de críticas asociadas al juego especificado.
     */
    public ArrayList<Critica> getCriticasPorJuego(int idJuego) {
        ArrayList<Critica> criticas = new ArrayList<>();
        try ( Connection conn = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String sql = "SELECT * FROM Criticas WHERE id_juego = ?";
            try ( PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, idJuego);
                try ( ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        int id = rs.getInt("id_critica");
                        int idUsuario = rs.getInt("id_usuario");
                        int puntuacion = rs.getInt("puntuacion");
                        String comentario = rs.getString("comentario");
                        java.sql.Date fechaCriticaSQL = rs.getDate("fecha_critica");
                        java.util.Date fechaCritica = new java.util.Date(fechaCriticaSQL.getTime()); // Convertir java.sql.Date a Date
                        Critica critica = new Critica(id, idJuego, idUsuario, puntuacion, comentario, (Date) fechaCritica);
                        criticas.add(critica);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener críticas por juego: " + e.getMessage());
        }
        return criticas;
    }
    
    /**
     * Método para actualizar una crítica en la base de datos.
     * 
     * @param critica La crítica actualizada.
     */
    public void update(Critica critica) {
        try (Connection conn = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String sql = "UPDATE Criticas SET id_juego=?, id_usuario=?, puntuacion=?, comentario=?, fecha_critica=? WHERE id_critica=?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, critica.getIdJuego());
                pstmt.setInt(2, critica.getIdUsuario());
                pstmt.setInt(3, critica.getPuntuacion());
                pstmt.setString(4, critica.getComentario());
                pstmt.setDate(5, new java.sql.Date(critica.getFechaCritica().getTime()));
                pstmt.setInt(6, critica.getId());
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la crítica: " + e.getMessage());
        }
    }

    /**
     * Método para obtener una crítica por su ID.
     * 
     * @param idCritica El ID de la crítica que se desea obtener.
     * @return La crítica encontrada, o null si no se encuentra ninguna crítica con el ID especificado.
     */
    public Critica read(int idCritica) {
        Critica critica = null;
        try (Connection conn = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String sql = "SELECT * FROM Criticas WHERE id_critica = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, idCritica);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        int id = rs.getInt("id_critica");
                        int idJuego = rs.getInt("id_juego");
                        int idUsuario = rs.getInt("id_usuario");
                        int puntuacion = rs.getInt("puntuacion");
                        String comentario = rs.getString("comentario");
                        java.sql.Date fechaCriticaSQL = rs.getDate("fecha_critica");
                        java.util.Date fechaCritica = new java.util.Date(fechaCriticaSQL.getTime());
                        critica = new Critica(id, idJuego, idUsuario, puntuacion, comentario, (Date) fechaCritica);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener la crítica: " + e.getMessage());
        }
        return critica;
    }

    /**
     * Método para eliminar una crítica de la base de datos.
     * 
     * @param idCritica El ID de la crítica que se desea eliminar.
     */
    public void delete(int idCritica) {
        try (Connection conn = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            String sql = "DELETE FROM Criticas WHERE id_critica=?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, idCritica);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar la crítica: " + e.getMessage());
        }
    }
    
    /**
     * Cierra la conexión a la base de datos.
     */
    public void close() {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión");
        }
    }
}
