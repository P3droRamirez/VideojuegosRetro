/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Juego;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Esta clase proporciona métodos para realizar operaciones CRUD (crear, leer, actualizar y eliminar) en la tabla Juegos de la base de datos.
 * 
 * Utiliza una conexión JDBC para interactuar con la base de datos TiendaVideojuegos.
 * 
 * @author pedro
 */
public class JuegoDao {

    private Connection conexion;
    private final String USUARIO = "root";
    private final String PASSWORD = "root";
    private final String MAQUINA = "localhost";
    private final String BD = "TiendaVideojuegos";

    /**
     * Constructor de la clase JuegoDao.
     * 
     * Establece la conexión con la base de datos al momento de la creación del objeto.
     */
    public JuegoDao() {
        conexion = conectar();
    }

    /**
     * Establece una conexión con la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD");
        }
        return con;
    }

    /**
     * Crea un nuevo juego en la base de datos.
     * 
     * @param juego El juego a crear.
     */
    public void create(Juego juego) {
        if (juego != null) {
            String sql = "INSERT INTO Juegos (titulo, anio_lanzamiento, multijugador, precio, id_consola) "
                    + "VALUES(?, ?, ?, ?, ?)";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, juego.getTitulo());
                sentencia.setString(2, juego.getAnio_lanzamiento());
                sentencia.setBoolean(3, juego.isMultijugador());
                sentencia.setDouble(4, juego.getPrecio());
                sentencia.setInt(5, juego.getId_consola());
                sentencia.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Error al insertar");
            }
        }
    }

    /**
     * Lee un juego de la base de datos por su título.
     * 
     * @param nombre El título del juego a buscar.
     * @return El juego encontrado, o null si no se encontró ninguno.
     */
    public Juego read(String nombre) {
        Juego juego = null;
        //Tengo que modificar este select para actualizar el buscador, utilizar like
        String sql = "SELECT * FROM Juegos WHERE left(titulo,3)=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setString(1, nombre);
            ResultSet rs = sentencia.executeQuery();

            if (rs.next()) {//Si existe registro
                int id = rs.getInt("id_juego");
                String titulo = rs.getString("titulo");
                String anioLanzamiento = rs.getString("anio_lanzamiento");
                boolean multijugador = rs.getBoolean("multijugador");
                double precio = rs.getDouble("precio");
                int idConsola = rs.getInt("id_consola");
                juego = new Juego(id, titulo, anioLanzamiento, multijugador, precio, idConsola);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar un juego");
        }
        return juego;
    }

    /**
     * Lee juegos de la base de datos que coincidan con una palabra clave en el título.
     * 
     * @param palabraClave La palabra clave a buscar en el título de los juegos.
     * @return Una lista de juegos encontrados que coinciden con la palabra clave.
     */
    public ArrayList<Juego> read2(String palabraClave) {
        ArrayList<Juego> juegosEncontrados = new ArrayList<>();
        String sql = "SELECT * FROM Juegos WHERE titulo LIKE ?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setString(1, "%" + palabraClave + "%");
            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id_juego");
                String titulo = rs.getString("titulo");
                String anioLanzamiento = rs.getString("anio_lanzamiento");
                boolean multijugador = rs.getBoolean("multijugador");
                double precio = rs.getDouble("precio");
                int idConsola = rs.getInt("id_consola");

                Juego juego = new Juego(id, titulo, anioLanzamiento, multijugador, precio, idConsola);
                juegosEncontrados.add(juego);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar los juegos");
        }
        return juegosEncontrados;
    }

    /**
     * Actualiza un juego en la base de datos.
     * 
     * @param juego El juego actualizado.
     */
    public void update(Juego juego) {
        if (juego != null) {
            String sql = "UPDATE Juegos SET titulo=?, anio_lanzamiento=?, multijugador=?, precio=?, id_consola=? WHERE id_juego=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, juego.getTitulo());
                sentencia.setString(2, juego.getAnio_lanzamiento());
                sentencia.setBoolean(3, juego.isMultijugador());
                sentencia.setDouble(4, juego.getPrecio());
                sentencia.setInt(5, juego.getId_consola());
                sentencia.setInt(6, juego.getId()); //asignamos la clave a buscar
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al actualizar un juego");
            }
        }
    }

    /**
     * Elimina un juego de la base de datos por su identificador.
     * 
     * @param id El identificador del juego a eliminar.
     */
    public void delete(int id) {
        String sql = "DELETE FROM Juegos WHERE id_juego = ?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            sentencia.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al eliminar un juego");
        }
    }
    
    /**
     * Cierra la conexión a la base de datos.
     */
    public void close() {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión");
        }
    }

}
