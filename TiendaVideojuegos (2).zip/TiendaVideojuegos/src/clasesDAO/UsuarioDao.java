/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Usuario;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * La clase UsuarioDao proporciona métodos para interactuar con la base de datos relacionados con la entidad Usuario.
 * 
 * Permite realizar operaciones como crear, leer, actualizar y eliminar usuarios en la base de datos.
 * 
 * @author pedro
 */
public class UsuarioDao {
    
    private Connection conexion;
    private final String USUARIO = "root";
    private final String PASSWORD = "root";
    private final String MAQUINA = "localhost";
    private final String BD = "TiendaVideojuegos";

    /**
     * Constructor de la clase UsuarioDao.
     */
    public UsuarioDao() {
        conexion = conectar();
    }
    
    /**
     * Método privado para establecer la conexión a la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar(){
       Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD");
        }
        return con;
    }
    
    /**
     * Crea un nuevo registro de usuario en la base de datos.
     * 
     * @param usuario El usuario a crear.
     */
    public void create(Usuario usuario) {
        if (usuario != null) {
            String sql = "INSERT INTO Usuarios (id_usuario, nombre_usuario, correo_electronico, contrasena) "
                    + "VALUES(?, ?, ?, ?)";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, usuario.getId());
                sentencia.setString(2, usuario.getNombre_usuario());
                sentencia.setString(3, usuario.getCorreo_electronico());
                sentencia.setString(4, usuario.getContrasena());
                
                sentencia.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Error al insertar");
            }
        }
    }
    
    /**
     * Lee un usuario de la base de datos según su ID.
     * 
     * @param id El ID del usuario a leer.
     * @return El usuario leído, o null si no se encontró ningún usuario con el ID especificado.
     */
    public Usuario read(int id) {
        Usuario usuario = null;
        String sql = "SELECT * FROM Usuarios WHERE id_usuario=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            ResultSet rs = sentencia.executeQuery();

            if (rs.next()) {//Si existe registro
                String nombre = rs.getString("nombre_usuario");
                String correo = rs.getString("correo_electronico");
                String pass = rs.getString("contrasena");
                usuario = new Usuario(id, nombre, correo, pass);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar un usuario");
        }
        return usuario;
    }
    
    /**
     * Actualiza un registro de usuario en la base de datos.
     * 
     * @param usuario El usuario a actualizar.
     */
    public void update(Usuario usuario) {
        if (usuario != null) {
            String sql = "UPDATE Usuarios SET nombre_usuario=?, correo_electronico=?, contrasena=? WHERE id_usuario=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, usuario.getNombre_usuario());
                sentencia.setString(2, usuario.getCorreo_electronico());
                sentencia.setString(3, usuario.getContrasena());
                sentencia.setInt(4, usuario.getId()); //asignamos la clave a buscar
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al actualizar un usuario");
            }
        }
    }
    
    /**
     * Elimina un registro de usuario de la base de datos según su ID.
     * 
     * @param id El ID del usuario a eliminar.
     */
    public void delete(int id) {
        String sql = "DELETE FROM Usuarios WHERE id_usuario = ?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            sentencia.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al eliminar al usuario");
        }
    }
    
    /**
     * Cierra la conexión a la base de datos.
     */
    public void close() {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión");
        }
    }
}
