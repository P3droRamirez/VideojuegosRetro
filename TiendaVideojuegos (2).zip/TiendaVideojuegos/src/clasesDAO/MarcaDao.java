/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesDAO;

import clasesPojo.Marca;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Esta clase proporciona métodos para acceder y manipular los datos de las marcas en la base de datos.
 * Utiliza la tabla "Marcas" en la base de datos "TiendaVideojuegos".
 * 
 * @author pedro
 */
public class MarcaDao {

    private Connection conexion;
    private final String USUARIO = "root";
    private final String PASSWORD = "root";
    private final String MAQUINA = "localhost";
    private final String BD = "TiendaVideojuegos";

    /**
     * Constructor de la clase MarcaDao.
     * Establece la conexión con la base de datos al instanciar el objeto.
     */
    public MarcaDao() {
        conexion = conectar();
    }

    /**
     * Establece la conexión con la base de datos.
     * 
     * @return La conexión establecida.
     */
    private Connection conectar() {
        Connection con = null;
        String url = "jdbc:mysql://" + MAQUINA + "/" + BD;
        try {
            con = DriverManager.getConnection(url, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar al SGBD");
        }
        return con;
    }

    /**
     * Inserta una nueva marca en la base de datos.
     * 
     * @param marca La marca a ser insertada.
     */
    public void create(Marca marca) {
        if (marca != null) {
            String sql = "INSERT INTO Marcas (id_marca, nombre_marca) "
                    + "VALUES(?, ?)";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setInt(1, marca.getId_marca());
                sentencia.setString(2, marca.getNombre_marca());
                sentencia.executeUpdate();
            } catch (SQLException e) {
                System.out.println("Error al insertar");
            }
        }
    }

    /**
     * Lee una marca de la base de datos dado su identificador.
     * 
     * @param id El identificador de la marca a leer.
     * @return La marca leída de la base de datos, o null si no se encuentra.
     */
    public Marca read(int id) {
        Marca marca = null;
        String sql = "SELECT * FROM Marcas WHERE id_marca=?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            ResultSet rs = sentencia.executeQuery();

            if (rs.next()) { // Si existe registro
                String nombre = rs.getString("nombre_marca");
                marca = new Marca(id, nombre);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar un usuario");
        }
        return marca;
    }

    /**
     * Actualiza una marca en la base de datos.
     * 
     * @param marca La marca con los nuevos datos a ser actualizados.
     */
    public void update(Marca marca) {
        if (marca != null) {
            String sql = "UPDATE Marcas SET nombre_marca=? WHERE id_marca=?";
            try {
                PreparedStatement sentencia = conexion.prepareStatement(sql);
                sentencia.setString(1, marca.getNombre_marca());
                sentencia.setInt(2, marca.getId_marca());
                sentencia.executeUpdate();
            } catch (SQLException ex) {
                System.out.println("Error al actualizar una marca");
            }
        }
    }

    /**
     * Elimina una marca de la base de datos dado su identificador.
     * 
     * @param id El identificador de la marca a ser eliminada.
     */
    public void delete(int id) {
        String sql = "DELETE FROM Marcas WHERE id_marca = ?";
        try {
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            sentencia.setInt(1, id);
            sentencia.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al eliminar al usuario");
        }
    }
    
    /**
     * Cierra la conexión a la base de datos.
     */
    public void close() {
        try {
            if (conexion != null) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión");
        }
    }
}
