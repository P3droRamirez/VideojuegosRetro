/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

import java.time.LocalDate;

/**
 * Esta clase representa un juego en el sistema de gestión de una tienda de videojuegos.
 * 
 * Cada juego tiene un identificador único, un título, año de lanzamiento, indica si es multijugador,
 * precio y el identificador de la consola a la que pertenece.
 * 
 * @author pedro
 */
public class Juego {
    
    private final int TAM_TITULO = 100;
    private int id;
    private String titulo;
    private String anio_lanzamiento;
    private boolean multijugador;
    private double precio;
    private int id_consola;

    /**
     * Constructor de la clase Juego.
     * 
     * @param id El identificador único del juego.
     */
    public Juego(int id) {
        this.id = id;
    }

    /**
     * Constructor de la clase Juego.
     * 
     * @param titulo El título del juego.
     * @param anio_lanzamiento El año de lanzamiento del juego.
     * @param multijugador Indica si el juego es multijugador o no.
     * @param precio El precio del juego.
     * @param id_consola El identificador de la consola a la que pertenece el juego.
     */
    public Juego(String titulo, String anio_lanzamiento, boolean multijugador, double precio, int id_consola) {
        this.titulo = titulo;
        this.anio_lanzamiento = anio_lanzamiento;
        this.multijugador = multijugador;
        this.precio = precio;
        this.id_consola = id_consola;
    }
    
    /**
     * Constructor de la clase Juego.
     * 
     * @param id El identificador único del juego.
     * @param titulo El título del juego.
     * @param anio_lanzamiento El año de lanzamiento del juego.
     * @param multijugador Indica si el juego es multijugador o no.
     * @param precio El precio del juego.
     * @param id_consola El identificador de la consola a la que pertenece el juego.
     */
    public Juego(int id, String titulo, String anio_lanzamiento, boolean multijugador, double precio, int id_consola) {
        this.id = id;
        this.titulo = titulo;
        this.anio_lanzamiento = anio_lanzamiento;
        this.multijugador = multijugador;
        this.precio = precio;
        this.id_consola = id_consola;
    }

    /**
     * Obtiene el identificador único del juego.
     * 
     * @return El identificador del juego.
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el identificador único del juego.
     * 
     * @param id El identificador único del juego.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el título del juego.
     * 
     * @return El título del juego.
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Establece el título del juego.
     * 
     * @param titulo El título del juego.
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene el año de lanzamiento del juego.
     * 
     * @return El año de lanzamiento del juego.
     */
    public String getAnio_lanzamiento() {
        return anio_lanzamiento;
    }

    /**
     * Establece el año de lanzamiento del juego.
     * 
     * @param anio_lanzamiento El año de lanzamiento del juego.
     */
    public void setAnio_lanzamiento(String anio_lanzamiento) {
        this.anio_lanzamiento = anio_lanzamiento;
    }

    /**
     * Verifica si el juego es multijugador o no.
     * 
     * @return true si el juego es multijugador, false si no lo es.
     */
    public boolean isMultijugador() {
        return multijugador;
    }

    /**
     * Establece si el juego es multijugador o no.
     * 
     * @param multijugador true si el juego es multijugador, false si no lo es.
     */
    public void setMultijugador(boolean multijugador) {
        this.multijugador = multijugador;
    }

    /**
     * Obtiene el precio del juego.
     * 
     * @return El precio del juego.
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * Establece el precio del juego.
     * 
     * @param precio El precio del juego.
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * Obtiene el identificador de la consola a la que pertenece el juego.
     * 
     * @return El identificador de la consola.
     */
    public int getId_consola() {
        return id_consola;
    }

    /**
     * Establece el identificador de la consola a la que pertenece el juego.
     * 
     * @param id_consola El identificador de la consola.
     */
    public void setId_consola(int id_consola) {
        this.id_consola = id_consola;
    }

    /**
     * Devuelve una representación de cadena del objeto Juego.
     * 
     * @return Una cadena que representa el objeto Juego.
     */
    @Override
    public String toString() {
        return "Juego{" + "id=" + id + ", titulo=" + titulo + ", anio_lanzamiento=" + anio_lanzamiento + ", multijugador=" + multijugador + ", precio=" + precio + ", id_consola=" + id_consola + '}';
    }
}
