/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesPojo;

import java.sql.Date;

/**
 * La clase Critica representa una crítica realizada por un usuario a un juego en particular.
 * Contiene información sobre la puntuación otorgada, el comentario y la fecha de la crítica.
 * 
 * @author pedro
 */
public class Critica {
    
    private int id;
    private int idJuego;
    private int idUsuario;
    private int puntuacion;
    private String comentario;
    private Date fechaCritica;

    /**
     * Constructor de la clase Critica.
     * 
     * @param idJuego El ID del juego al que se refiere la crítica.
     */
    public Critica(int idJuego) {
        this.idJuego = idJuego;
    }

    /**
     * Constructor de la clase Critica.
     * 
     * @param idJuego El ID del juego al que se refiere la crítica.
     * @param idUsuario El ID del usuario que realiza la crítica.
     * @param puntuacion La puntuación otorgada en la crítica.
     * @param comentario El comentario realizado en la crítica.
     * @param fechaCritica La fecha en que se realizó la crítica.
     */
    public Critica(int idJuego, int idUsuario, int puntuacion, String comentario, Date fechaCritica) {
        this.idJuego = idJuego;
        this.idUsuario = idUsuario;
        this.puntuacion = puntuacion;
        this.comentario = comentario;
        this.fechaCritica = fechaCritica;
    }

    /**
     * Constructor de la clase Critica.
     * 
     * @param id El ID de la crítica.
     * @param idJuego El ID del juego al que se refiere la crítica.
     * @param idUsuario El ID del usuario que realiza la crítica.
     * @param puntuacion La puntuación otorgada en la crítica.
     * @param comentario El comentario realizado en la crítica.
     * @param fechaCritica La fecha en que se realizó la crítica.
     */
    public Critica(int id, int idJuego, int idUsuario, int puntuacion, String comentario, Date fechaCritica) {
        this.id = id;
        this.idJuego = idJuego;
        this.idUsuario = idUsuario;
        this.puntuacion = puntuacion;
        this.comentario = comentario;
        this.fechaCritica = fechaCritica;
    }

    /**
     * Método para obtener el ID de la crítica.
     * 
     * @return El ID de la crítica.
     */
    public int getId() {
        return id;
    }

    /**
     * Método para establecer el ID de la crítica.
     * 
     * @param id El ID de la crítica.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Método para obtener el ID del juego al que se refiere la crítica.
     * 
     * @return El ID del juego.
     */
    public int getIdJuego() {
        return idJuego;
    }

    /**
     * Método para establecer el ID del juego al que se refiere la crítica.
     * 
     * @param idJuego El ID del juego.
     */
    public void setIdJuego(int idJuego) {
        this.idJuego = idJuego;
    }

    /**
     * Método para obtener el ID del usuario que realiza la crítica.
     * 
     * @return El ID del usuario.
     */
    public int getIdUsuario() {
        return idUsuario;
    }

    /**
     * Método para establecer el ID del usuario que realiza la crítica.
     * 
     * @param idUsuario El ID del usuario.
     */
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    /**
     * Método para obtener la puntuación otorgada en la crítica.
     * 
     * @return La puntuación de la crítica.
     */
    public int getPuntuacion() {
        return puntuacion;
    }

    /**
     * Método para establecer la puntuación otorgada en la crítica.
     * 
     * @param puntuacion La puntuación de la crítica.
     */
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    /**
     * Método para obtener el comentario realizado en la crítica.
     * 
     * @return El comentario de la crítica.
     */
    public String getComentario() {
        return comentario;
    }

    /**
     * Método para establecer el comentario realizado en la crítica.
     * 
     * @param comentario El comentario de la crítica.
     */
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    /**
     * Método para obtener la fecha en que se realizó la crítica.
     * 
     * @return La fecha de la crítica.
     */
    public Date getFechaCritica() {
        return fechaCritica;
    }

    /**
     * Método para establecer la fecha en que se realizó la crítica.
     * 
     * @param fechaCritica La fecha de la crítica.
     */
    public void setFechaCritica(Date fechaCritica) {
        this.fechaCritica = fechaCritica;
    }

    @Override
    public String toString() {
        return "Critica{" + "id=" + id + ", idJuego=" + idJuego + ", idUsuario=" + idUsuario + ", puntuacion=" + puntuacion + ", comentario=" + comentario + ", fechaCritica=" + fechaCritica + '}';
    }
    
    
}
