/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package app;

import clasesDAO.*;
import clasesPojo.*;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Scanner;
import static org.junit.Assert.*;

public class AppOptimizadaTest {
    
    private AppOptimizada app;
    private Scanner sc;
    private UsuarioDao usuarioDao;
    private MarcaDao marcaDao;
    private ConsolaDao consolaDao;
    private JuegoDao juegoDao;
    private CriticaDao criticaDao;
    private VentaDao ventaDao;
    private ArrayList<Usuario> listaUsuarios;
    private ArrayList<Marca> listaMarcas;
    private ArrayList<Consola> listaConsolas;
    private ArrayList<Juego> listaJuegos;
    private ArrayList<Critica> listaCriticas;
    private ArrayList<Venta> listaVentas;

    @Before
    public void setUp() {
        app = new AppOptimizada();
        sc = new Scanner(System.in);
        usuarioDao = new UsuarioDao();
        marcaDao = new MarcaDao();
        consolaDao = new ConsolaDao();
        juegoDao = new JuegoDao();
        criticaDao = new CriticaDao();
        ventaDao = new VentaDao();
        listaUsuarios = new ArrayList<>();
        listaMarcas = new ArrayList<>();
        listaConsolas = new ArrayList<>();
        listaJuegos = new ArrayList<>();
        listaCriticas = new ArrayList<>();
        listaVentas = new ArrayList<>();
    }
    /*Los errores que estás viendo son una excepción NoSuchElementException, que indica que no se pudo encontrar el siguiente elemento mientras se realiza la operación de lectura de datos con Scanner.

Este error específico parece estar ocurriendo en los metodos que requieren de un Scanner, de la clase AppOptimizada. Estos métodos aparentemente están tratando de leer un entero usando Scanner.nextInt(), pero no hay un elemento siguiente disponible en el flujo de entrada.

Para solucionar este problema, necesitas asegurarte de que el Scanner esté leyendo desde una fuente de entrada válida y que haya elementos disponibles para leer. Es posible que necesites verificar si el flujo de entrada (System.in) está configurado correctamente antes de usarlo en cualquier metodo de prueba unitaria*/



    @Test
    public void testMostrarUsuarios() {
        System.out.println("mostrarUsuarios");
        app.mostrarUsuarios(listaUsuarios);
    }

    @Test
    public void testMostrarMarcas() {
        System.out.println("mostrarMarcas");
        app.mostrarMarcas(listaMarcas);
    }

    @Test
    public void testMostrarConsolas() {
        System.out.println("mostrarConsolas");
        app.mostrarConsolas(listaConsolas);
    }

    @Test
    public void testMostrarJuegos() {
        System.out.println("mostrarJuegos");
        app.mostrarJuegos(listaJuegos);
    }

    @Test
    public void testMostrarCriticas() {
        System.out.println("mostrarCriticas");
        app.mostrarCriticas(listaCriticas);
    }

    @Test
    public void testMostrarVentas() {
        System.out.println("mostrarVentas");
        app.mostrarVentas(listaVentas);
    }

    @Test
    public void testObtenerUsuariosDesdeBD() {
        System.out.println("obtenerUsuariosDesdeBD");
        ArrayList<Usuario> result = app.obtenerUsuariosDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testObtenerMarcasDesdeBD() {
        System.out.println("obtenerMarcasDesdeBD");
        ArrayList<Marca> result = app.obtenerMarcasDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testObtenerConsolasDesdeBD() {
        System.out.println("obtenerConsolasDesdeBD");
        ArrayList<Consola> result = app.obtenerConsolasDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testObtenerVideojuegosDesdeBD() {
        System.out.println("obtenerVideojuegosDesdeBD");
        ArrayList<Juego> result = app.obtenerVideojuegosDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testObtenerCriticasDesdeBD() {
        System.out.println("obtenerCriticasDesdeBD");
        ArrayList<Critica> result = app.obtenerCriticasDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testObtenerVentasDesdeBD() {
        System.out.println("obtenerVentasDesdeBD");
        ArrayList<Venta> result = app.obtenerVentasDesdeBD();
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testBuscarJuegosPorTitulo() {
        System.out.println("buscarJuegosPorTitulo");
        String busqueda = "Example Title";
        ArrayList<Juego> listaJuegos = app.obtenerVideojuegosDesdeBD();
        JuegoDao juegoDao = new JuegoDao();
        ArrayList<Juego> result = app.buscarJuegosPorTitulo(busqueda, listaJuegos, juegoDao);
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }
    


    @Test
    public void testMostrarConsulta() {
        System.out.println("mostrarConsulta");
        String consulta = "Example Query";
        app.mostrarConsulta(consulta);
    }
}


